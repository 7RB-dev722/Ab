// This function handles sending Push Notifications
// Deploy with: supabase functions deploy smooth-processor

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import webpush from "https://esm.sh/web-push@3.6.3"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

// Get environment variables
const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY')
const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY')
const supabaseUrl = Deno.env.get('SUPABASE_URL')
const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')

// Setup Web Push
if (vapidPublicKey && vapidPrivateKey) {
  webpush.setVapidDetails(
    'mailto:admin@cheatloop.com',
    vapidPublicKey,
    vapidPrivateKey
  )
}

serve(async (req) => {
  try {
    // 1. Check for missing secrets
    if (!vapidPublicKey || !vapidPrivateKey || !supabaseUrl || !supabaseServiceRoleKey) {
      console.error("Missing required secrets in Edge Function!")
      return new Response(
        JSON.stringify({ error: "Server configuration error: Missing secrets" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      )
    }

    // 2. Parse the webhook payload
    const { record } = await req.json()
    
    // Only notify on new purchase intents
    if (!record || !record.product_title) {
        console.log("No record data or missing product_title")
        return new Response(JSON.stringify({ message: 'No record data' }), { status: 200 })
    }

    console.log(`Processing notification for: ${record.product_title}`)

    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey)

    const payload = JSON.stringify({
      title: `طلب شراء جديد: ${record.product_title}`,
      body: `${record.email} - ${record.country}`,
      url: '/admin'
    })

    // 3. Fetch all subscribed endpoints
    const { data: subscriptions, error } = await supabase
      .from('admin_push_subscriptions')
      .select('*')

    if (error) {
      console.error("Database error fetching subscriptions:", error)
      throw error
    }

    console.log(`Found ${subscriptions?.length || 0} subscriptions`)

    if (!subscriptions || subscriptions.length === 0) {
        return new Response(JSON.stringify({ message: 'No subscriptions found' }), { status: 200 })
    }

    // 4. Send notifications
    const results = await Promise.all(subscriptions.map(sub => {
      const pushSubscription = {
        endpoint: sub.endpoint,
        keys: {
          p256dh: sub.p256dh,
          auth: sub.auth
        }
      }
      
      return webpush.sendNotification(pushSubscription, payload)
        .then(() => ({ success: true }))
        .catch(err => {
          console.error('Push error for subscription:', sub.id, err)
          if (err.statusCode === 410 || err.statusCode === 404) {
            // Subscription expired, delete it
            supabase.from('admin_push_subscriptions').delete().eq('id', sub.id).then()
          }
          return { success: false, error: err }
        })
    }))

    const successCount = results.filter(r => r.success).length
    console.log(`Sent ${successCount} notifications successfully`)

    return new Response(
      JSON.stringify({ message: `Sent ${successCount} notifications` }),
      { headers: { "Content-Type": "application/json" } },
    )
  } catch (e) {
    console.error("Unexpected error:", e)
    return new Response(
      JSON.stringify({ error: e.message }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    )
  }
})
