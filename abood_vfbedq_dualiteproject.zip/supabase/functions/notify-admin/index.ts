// This file is for reference. You must deploy this to Supabase Edge Functions.
// Follow instructions: https://supabase.com/docs/guides/functions

import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import webpush from "https://esm.sh/web-push@3.6.3"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const vapidPublicKey = Deno.env.get('VAPID_PUBLIC_KEY')!
const vapidPrivateKey = Deno.env.get('VAPID_PRIVATE_KEY')!
const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

webpush.setVapidDetails(
  'mailto:admin@cheatloop.com',
  vapidPublicKey,
  vapidPrivateKey
)

const supabase = createClient(supabaseUrl, supabaseServiceRoleKey)

serve(async (req) => {
  try {
    const { record } = await req.json()
    
    // Only notify on new purchase intents
    if (!record || !record.product_title) {
        return new Response(JSON.stringify({ message: 'No record data' }), { status: 200 })
    }

    const payload = JSON.stringify({
      title: `طلب شراء جديد: ${record.product_title}`,
      body: `${record.email} - ${record.country}`,
      url: '/admin'
    })

    // Fetch all subscribed endpoints
    const { data: subscriptions, error } = await supabase
      .from('admin_push_subscriptions')
      .select('*')

    if (error) throw error

    const results = await Promise.all(subscriptions.map(sub => {
      const pushSubscription = {
        endpoint: sub.endpoint,
        keys: {
          p256dh: sub.p256dh,
          auth: sub.auth
        }
      }
      
      return webpush.sendNotification(pushSubscription, payload)
        .catch(err => {
          if (err.statusCode === 410) {
            // Subscription expired, delete it
            return supabase.from('admin_push_subscriptions').delete().eq('id', sub.id)
          }
          console.error('Push error', err)
        })
    }))

    return new Response(
      JSON.stringify({ message: `Sent ${results.length} notifications` }),
      { headers: { "Content-Type": "application/json" } },
    )
  } catch (e) {
    return new Response(
      JSON.stringify({ error: e.message }),
      { status: 500, headers: { "Content-Type": "application/json" } },
    )
  }
})
