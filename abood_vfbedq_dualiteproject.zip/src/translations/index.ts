import { en } from './en';
import { ar } from './ar';
import { tr } from './tr';

export const translations = {
    en,
    ar,
    tr,
};
